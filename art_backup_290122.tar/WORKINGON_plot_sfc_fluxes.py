#
import sys
import os
import numpy as np
import cmocean
import matplotlib.pyplot as plt
from pylab import *
import netCDF4 as nc
#import tol_colors 
#from mpl_toolkits.basemap import Basemap

#----------plot_FAF.py------------ LOAD ALL DATA
datadir  = '/home/netapp-clima-users1/rnavarro/ANALYSIS/BLAKER/SFC-fluxes_v2/DATA'
filename  = ["tau_x_correction_v2.nc","tau_y_correction_v2.nc","salt_sfc_correction_v2.nc","temp_sfc_correction_v2.nc"]

fn = os.path.join(datadir,filename[0])
print("Working on %s" % fn)
file = nc.Dataset(fn)
X1   = file.variables['XT_OCEAN30_390'][:]
Y1   = file.variables['YT_OCEAN'][:]
tau_x_fafmip = np.mean(file.variables['TAU_X_V2'][:,:],axis=1)
file.close()

fn = os.path.join(datadir,filename[1])
print("Working on %s" % fn)
file = nc.Dataset(fn)
X1   = file.variables['XT_OCEAN30_390'][:]
Y1   = file.variables['YT_OCEAN'][:]
tau_y_fafmip = np.mean(file.variables['TAU_Y_V2'][:,:],axis=1)
file.close()

fn = os.path.join(datadir,filename[2])
print("Working on %s" % fn)
file = nc.Dataset(fn)
X2   = file.variables['XT_OCEAN31_390'][:]
Y2   = file.variables['YT_OCEAN'][:]
PME_fafmip = np.mean(file.variables['PME_V2'][:,:],axis=1)
file.close()

fn = os.path.join(datadir,filename[3])
print("Working on %s" % fn)
file = nc.Dataset(fn)
X3   = file.variables['XT_OCEAN31_390'][:]
Y3   = file.variables['YT_OCEAN'][:]
SFC_HFLUX_fafmip = np.mean(file.variables['SFC_HFLUX_V2'][:,:],axis=1)
file.close()

##---Control fields from the flux-only output
fn = os.path.join(datadir,'Blaker_flux-only_ocean_fluxes_timmean.nc')
print("Working on %s" % fn)
file = nc.Dataset(fn)
Xt = file.variables['xt_ocean'][:]
Yt = file.variables['yt_ocean'][:]
tau_x   = np.mean(np.squeeze(file.variables['tau_x'][:,:,:]),axis=1)
tau_y   = np.mean(np.squeeze(file.variables['tau_y'][:,:,:]),axis=1)
hflux_coupler     = np.mean(np.squeeze(file.variables['sfc_hflux_coupler'][:,:,:]),axis=1)
hflux_from_runoff = np.mean(np.squeeze(file.variables['sfc_hflux_from_runoff'][:,:,:]),axis=1)
hflux_pme         = np.mean(np.squeeze(file.variables['sfc_hflux_pme'][:,:,:]),axis=1)
evap    = np.mean(np.squeeze(file.variables['evap'][:,:,:]),axis=1)
lprec   = np.mean(np.squeeze(file.variables['lprec'][:,:,:]),axis=1)
runoff  = np.mean(np.squeeze(file.variables['runoff'][:,:,:]),axis=1)
pme_sbc = np.mean(np.squeeze(file.variables['pme_sbc'][:,:,:]),axis=1)
file.close()

tau       = np.sqrt(tau_x**2 + tau_y**2)
SFC_HFLUX = hflux_coupler + hflux_from_runoff + hflux_pme
PME       = pme_sbc

##------------------------PLOTTING
#rc('text',usetex=True)
rc('figure', figsize=(8.27,11.69))

fig = plt.figure(1)
fig.subplots_adjust(hspace=0.25,wspace=0.2)

##---STRESS
ax = fig.add_subplot(3,1,1)

ax.plot(Y1,tau_x,'-',color='k',linewidth=1.5)
ax.plot(Y1,tau_x_fafmip,'-',color='k',linewidth=1.5)
ax.plot(Y1,tau_x+tau_x_fafmip,'-',color='r',linewidth=1.5)

ax.axis([-45,45,-.10,.20])

plt.title('Stress',fontsize=16,color='k')
plt.axhline(y=0.0,color='k',linestyle='--',linewidth=1.5) #includes zero line
plt.xticks([-90,-60,-30,0,30,60,90],[],fontsize=16)
plt.yticks(fontsize=16);

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

ax.set_ylabel('[$10^{3}Pa$]',fontsize=16)

##---WATER
ax = fig.add_subplot(3,1,2)

ax.plot(Yt,((PME/1025)*(86400*1000))*(365/1000),'-',color='k',linewidth=1.5)
ax.plot(Yt,((PME_fafmip/1025)*(86400*1000))*(365/1000),'-',color='k',linewidth=1.5)
ax.plot(Yt,(((PME+PME_fafmip)/1025)*(86400*1000))*(365/1000),'-',color='r',linewidth=1.5)

ax.axis([-45,45,-1,1.5])

plt.title('Water',fontsize=16,color='k')
plt.axhline(y=0.0,color='k',linestyle='--',linewidth=1.5) #includes zero line
plt.xticks([-90,-60,-30,0,30,60,90],[],fontsize=16)
plt.yticks(fontsize=16);

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

ax.set_ylabel('[$m year^{-1}$]',fontsize=16)

##---HEAT
ax = fig.add_subplot(3,1,3)

ax.plot(Yt,SFC_HFLUX,'-',color='k',linewidth=1.5)
ax.plot(Yt,SFC_HFLUX_fafmip,'-',color='k',linewidth=1.5)
ax.plot(Yt,SFC_HFLUX+SFC_HFLUX_fafmip,'-',color='r',linewidth=1.5)
ax.axis([-90,90,-80,60])

plt.title('Heat',fontsize=16,color='k')
plt.axhline(y=0.0,color='k',linestyle='--',linewidth=1.5) #includes zero line
plt.xticks([-90,-60,-30,0,30,60,90],['90S','60S','30S','0','30N','60N','90N'],fontsize=16)
plt.yticks(fontsize=16);

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

ax.set_ylabel('[$Wm^{-2}$]',fontsize=16)

plt.show()
#plt.savefig('STC_OHC_GLB_sfc_fluxes.png',transparent = True, bbox_inches='tight',dpi=600)

