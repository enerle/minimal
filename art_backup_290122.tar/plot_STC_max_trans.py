import sys
import os
import numpy as np
from scipy import stats
import cmocean
import matplotlib.pyplot as plt
from pylab import *
import netCDF4 as nc

#---------------------- LOAD ALL DATA
#datadir  = '/home/netapp-clima-users1/rnavarro/ANALYSIS/BLAKER/DATA'
datadir  = '/home/clima-archive2/rfarneti/RENE/DATA/'

exp       = ["Stress","Water","Heat","All","control"]
filename1 = ["STC_max_trans_FAFSTRESS_v2.nc","STC_max_trans_FAFWATER_v2.nc","STC_max_trans_FAFHEAT_v2.nc","STC_max_trans_FAFALL_v2.nc","STC_max_trans_flux-only_v2.nc"]

time        = [None]*len(exp)
trans_north = [None]*len(exp)
trans_south = [None]*len(exp)

#---> Get the ACC
for i in range(len(exp)):  
    fn = os.path.join(datadir,filename1[i]) 
    print("Working on ", fn)
    file = nc.Dataset(fn)
    time[i] = file.variables['TIME'][:]/365 -2188.0
    trans_north[i] = file.variables['TRANS_T_NORTH'][:]
    trans_south[i] = file.variables['TRANS_T_SOUTH'][:]
    file.close()

##------------------------PLOTTING
#rc('text', usetex=True)
rc('figure', figsize=(11.69,8.27))

colors = ['black','blue','red','green','gray']
styles = ['solid','solid','solid','solid','solid']

fig = plt.figure(1)

ax = fig.add_subplot(2,1,1)
for i in range(len(exp)):
    ax.plot(time[i],trans_north[i],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])
    #ax.plot(time[i],trans_north[i]-trans_north[-1],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])

###
ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.xticks([0,10,20,30,40,50,60,70],[])

plt.title("North",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.axis([0,70,38,48])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

ax = fig.add_subplot(2,1,2)
for i in range(len(exp)):
    ax.plot(time[i],trans_south[i],color=colors[i],linestyle=styles[i],linewidth=2.0,label=exp[i])
    #ax.plot(time[i],trans_south[i]-trans_south[-1],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])
###

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.title("South",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.set_xlabel("Time [years]",fontsize=16)
ax.legend(loc=3,ncol=2, fontsize=16)
ax.axis([0,70,38,48])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

plt.show()
#plt.savefig('./Figures/STC-conv-timeseries.png',transparent = True, bbox_inches='tight',dpi=600)

