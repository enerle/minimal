import sys
import os
import numpy as np
from scipy import stats
import cmocean
import matplotlib.pyplot as plt
from pylab import *
import netCDF4 as nc

#---------------------- LOAD ALL DATA
datadir  = '/home/clima-archive2/rfarneti/RENE/DATA/'

exp       = ["Stress","Water","Heat","All","control"]
filename1 = ["STC_FAFSTRESS.nc","STC_FAFWATER.nc","STC_FAFHEAT.nc","STC_FAFALL.nc","STC_flux-only.nc"]

conv      = [None]*len(exp)
trans9n   = [None]*len(exp)
trans9s   = [None]*len(exp)

conv_int      = [None]*len(exp)
trans9n_int   = [None]*len(exp)
trans9s_int   = [None]*len(exp)
time          = [None]*len(exp)

#---> Get the ACC
for i in range(len(exp)):  
    fn = os.path.join(datadir,filename1[i]) 
    print("Working on ", fn)
    file = nc.Dataset(fn)
    time[i]    = file.variables['TIME'][:]/365 -2188.0

    conv[i]        = np.squeeze(file.variables['CONV'][:])
    trans9n[i]     = np.squeeze(file.variables['TRANS9N'][:])
    trans9s[i]     = np.squeeze(file.variables['TRANS9S'][:])

    conv_int[i]    = np.squeeze(file.variables['CONV_INT'][:])
    trans9n_int[i] = np.squeeze(file.variables['TRANS9N_INT'][:])
    trans9s_int[i] = np.squeeze(file.variables['TRANS9S_INT'][:])
    file.close()

##------------------------PLOTTING
#rc('text', usetex=True)
rc('figure', figsize=(11.69,8.27))

colors = ['black','blue','red','green','gray']
styles = ['solid','solid','solid','solid','solid']

fig = plt.figure(1)

ax = fig.add_subplot(3,1,1)
for i in range(len(exp)):
    #ax.plot(time[i],conv[i]-conv[-1],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])
    ax.plot(time[i],conv[i],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])

###
ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.xticks([0,10,20,30,40,50,60,70],[])

plt.title("Total convergence",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
#ax.axis([0,70,-4,4])
ax.axis([0,70,50,57])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

ax = fig.add_subplot(3,1,2)
for i in range(len(exp)):
    #ax.plot(time[i],conv[i]-conv[-1],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])
    ax.plot(time[i],abs(trans9n[i]),color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])

###
ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.xticks([0,10,20,30,40,50,60,70],[])

plt.title("Total mass transport across 9N",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
#ax.axis([0,70,-4,4])
ax.axis([0,70,20,25])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

ax = fig.add_subplot(3,1,3)
for i in range(len(exp)):
    #ax.plot(time[i],conv_int[i]-conv_int[-1],color=colors[i],linestyle=styles[i],linewidth=2.0,label=exp[i])
    ax.plot(time[i],trans9s[i],color=colors[i],linestyle=styles[i],linewidth=2.0,label=exp[i])
###

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.title("Total mass transport across 9S",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.set_xlabel("Time [years]",fontsize=16)
ax.legend(loc=3,ncol=2, fontsize=16)
#ax.axis([0,70,-4,4])
ax.axis([0,70,30,35])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

#plt.show()
#plt.savefig('./Figures/STC-conv-timeseries.png',transparent = True, bbox_inches='tight',dpi=600)

##INTERIOR

fig = plt.figure(2)

ax = fig.add_subplot(3,1,1)
for i in range(len(exp)):
    ax.plot(time[i],conv_int[i],color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])

###
ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.xticks([0,10,20,30,40,50,60,70],[])

plt.title("Interior convergence",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.axis([0,70,10,15])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

ax = fig.add_subplot(3,1,2)
for i in range(len(exp)):
    ax.plot(time[i],abs(trans9n_int[i]),color=colors[i],linestyle=styles[i],linewidth=2.0, label = exp[i])

###
ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.xticks([0,10,20,30,40,50,60,70],[])

plt.title("Interior mass transport across 9N",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.axis([0,70,0,4])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

ax = fig.add_subplot(3,1,3)
for i in range(len(exp)):
    ax.plot(time[i],trans9s_int[i],color=colors[i],linestyle=styles[i],linewidth=2.0,label=exp[i])
###

ax.spines['top'].set_linewidth(2);  ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2); ax.spines['right'].set_linewidth(2)
ax.xaxis.set_tick_params(width=2);  ax.yaxis.set_tick_params(width=2)

plt.title("Interior mass transport across 9S",fontsize=16)
ax.set_ylabel("[Sv]",fontsize=16)
ax.set_xlabel("Time [years]",fontsize=16)
ax.legend(loc=3,ncol=2, fontsize=16)
ax.axis([0,70,8,12])

#plt.axhline(y=0.0,color='k',linestyle='--',linewidth=2) #includes zero line
plt.yticks(fontsize=16); plt.xticks(fontsize=16)
###

plt.show()
#plt.savefig('./Figures/STC-conv-timeseries.png',transparent = True, bbox_inches='tight',dpi=600)
